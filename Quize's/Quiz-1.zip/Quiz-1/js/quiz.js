//1. Write a program to take two numbers as input and print their sum.

let a = parseInt(prompt("Enter first number: "));
let b = parseInt(prompt("Enter second number: "));

let sum = a + b;

console.log("Sum = " + sum);

/*2. Using JavaScript operators, calculate and print:
Area of a rectangle (length × width)
Perimeter of a rectangle (2 × (length + width))*/

let length = parseFloat(prompt("Enter length: "));
let width = parseFloat(prompt("Enter width: "));

// Calculations
let area = length * width;
let perimeter = 2 * (length + width);

// Output
console.log("Area of Rectangle = " + area);
console.log("Perimeter of Rectangle = " + perimeter);


//3. Check whether a number is even or odd using an if-else condition.

let num = parseInt(prompt("Enter a number: "));

if (num % 2 === 0) {
    console.log(num + " is Even");
} else {
    console.log(num + " is Odd");
}

//4. Take a number from the user and print whether it is positive, negative, or zero.

let num1 = parseFloat(prompt("Enter a number: "));

if (num > 0) {
    console.log(num + " is Positive");
}
else if (num < 0) {
    console.log(num + " is Negative");
}
else {
    console.log("The number is Zero");
}


//5. Write a program using switch-case to print the day of the week (0–6).

let day = parseInt(prompt("Enter a number (0–6): "));

switch (day) {
    case 0:
        console.log("Sunday");
        break;

    case 1:
        console.log("Monday");
        break;

    case 2:
        console.log("Tuesday");
        break;

    case 3:
        console.log("Wednesday");
        break;

    case 4:
        console.log("Thursday");
        break;

    case 5:
        console.log("Friday");
        break;

    case 6:
        console.log("Saturday");
        break;

    default:
        console.log("Invalid input! Please enter a number between 0 and 6.");
}

//6. Print numbers from 1 to 50 using a for loop.

for (let i = 1; i <= 50; i++) {
    console.log(i);
}

//7. Print the sum of numbers from 1 to 100 using a while loop

let i = 1;
let sum1 = 0;

while (i <= 100) {
    sum += i;
    i++;
}

console.log("Sum of numbers from 1 to 100 = " + sum);

/*7. Print the following pattern using a nested loop:
*
**
***
****
*****
*/

let pattern = "";

for (let i = 1; i <= 5; i++) {
    for (let j = 1; j <= i; j++) {
        pattern += "*";
    }
    pattern += "\n";
}

console.log(pattern);


//9. Create a function greet(name) that returns “Hello, name!”.

function greet(name) {
    return "Hello, " + name + "!";
}

console.log(greet("Divya"));



//10. Write a JavaScript function to find the maximum of three numbers (user-defined function).

function findMax(a, b, c) {
    if (a >= b && a >= c) {
        return a;
    } else if (b >= a && b >= c) {
        return b;
    } else {
        return c;
    }
}

console.log("Maximum =", findMax(10, 25, 15));


/* 11. Write a program using built-in string functions to:
Convert a string to uppercase
Find its length
Extract substring from index 2 to 6 */

let str = "javascript";

// Convert to uppercase
let upper = str.toUpperCase();

// Find length
let length1 = str.length;

// Extract substring from index 2 to 6
let sub = str.substring(2, 6);  // index 2 to 5

console.log("Uppercase:", upper);
console.log("Length:", length);
console.log("Substring (2 to 6):", sub);


//12. Create an object student with properties: name, age, course. Print all keys and values.

let student = {
    name: "Divya",
    age: 21,
    course: "JavaScript"
};

for (let key in student) {
    console.log(key + ": " + student[key]);
}


//13. Add a method display() to the above student object that prints student details.

let student1 = {
    name: "Divya",
    age: 21,
    course: "JavaScript",

    display: function () {
        console.log("Name:", this.name);
        console.log("Age:", this.age);
        console.log("Course:", this.course);
    }
};

student1.display();


/* 14. Use the Math object to:
Generate a random number between 1–100
Find √144
Round 4.78 to nearest integer. */

// Random number 1–100
let rand = Math.floor(Math.random() * 100) + 1;

// Square root of 144
let root = Math.sqrt(144);

// Round 4.78
let roundVal = Math.round(4.78);

console.log("Random:", rand);
console.log("Square root:", root);
console.log("Rounded:", roundVal);


/* 15. Using Date() object, print:
Current date
Current month name
Current time (HH:MM:SS) */

let now = new Date();

// Current date
console.log("Date:", now.toDateString());

// Month name
let months = ["January", "February", "March", "April", "May", "June", "July",
    "August", "September", "October", "November", "December"];
console.log("Month:", months[now.getMonth()]);

// Current time
let time = now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds();
console.log("Time:", time);


/* 16. Create an array of 5 fruits. Perform:
Add a fruit at end
Remove the first fruit
Sort the array */

let fruits = ["Mango", "Apple", "Banana", "Grapes", "Orange"];

// Add fruit at end
fruits.push("Pineapple");

// Remove first fruit
fruits.shift();

// Sort array
fruits.sort();

console.log(fruits);


// 17. Write a program to find the largest number in an array using a loop.

let numbers = [12, 45, 67, 23, 89, 34];
let max = numbers[0];

for (let i = 1; i < numbers.length; i++) {
    if (numbers[i] > max) {
        max = numbers[i];
    }
}

console.log("Largest:", max);



// 18. Write a JS function that returns the total count of even numbers in an array.

function countEven(arr) {
    let count = 0;
    for (let num of arr) {
        if (num % 2 === 0) count++;
    }
    return count;
}

console.log(countEven([2, 5, 8, 11, 14]));


// 22. Write a program that prints multiplication table of any number (e.g., 5).

let num2 = 5;

for (let i = 1; i <= 10; i++) {
    console.log(num + " × " + i + " = " + (num * i));
}


// 23. Using for...of, print all characters of a string one by one.

let str1 = "HELLO";

for (let ch of str) {
    console.log(ch);
}


/* 24. Create an array of student marks and calculate:
Total marks
Average marks
Highest marks */

let marks = [88, 92, 76, 81, 95];

let total = 0;
let highest = marks[0];

for (let m of marks) {
    total += m;
    if (m > highest) highest = m;
}

let average = total / marks.length;

console.log("Total:", total);
console.log("Average:", average);
console.log("Highest:", highest);